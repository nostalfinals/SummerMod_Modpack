# Enderscape 简体中文翻译（NeoForge 1.21.1）

适用于 **Enderscape 1.0.9**（`neoforge-1.21.1` 分支）的资源包。

## 安装

将 `Enderscape-zh_cn-NeoForge-1.21.1.zip` 放入 Minecraft 实例的 `resourcepacks` 文件夹，再在游戏的“资源包”界面启用它。也可以直接将本目录放入该文件夹。

## 内容与兼容性

- `pack_format` 为 **34**，对应 Minecraft 1.21 / 1.21.1。
- `zh_cn.json` 包含该分支英文语言文件的全部 **631** 个键，未混入 1.21.11 才加入的键。
- 其中 585 个共享键采用 Enderscape 1.21.11 分支已有的简体中文翻译；46 个在新分支已删除或改名、但 1.21.1 仍使用的键已按旧版功能和术语单独翻译。

来源：<https://github.com/Penumbra-MC/Enderscape>。
